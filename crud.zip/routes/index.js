var express = require('express')
var app = express()
 
app.get('/', function(req, res) {
    // render to views/index.ejs template file
    res.render('index', {title: 'hiii'})
})
 
app.get('/icons', function(req, res) {
    // render to views/index.ejs template file
    res.render('icons', {title: 'hiii'})
})

app.get('/list', function(req, res) {
    // render to views/index.ejs template file
    res.render('list', {title: 'hiii'})
})

app.get('/forms', function(req, res) {
    // render to views/index.ejs template file
    res.render('forms', {title: 'hiii'})
})

app.get('/alerts', function(req, res) {
    // render to views/index.ejs template file
    res.render('alerts', {title: 'hiii'})
})

app.get('/timeline', function(req, res) {
    // render to views/index.ejs template file
    res.render('timeline', {title: 'hiii'})
})
/** 
 * We assign app object to module.exports
 * 
 * module.exports exposes the app object as a module
 * 
 * module.exports should be used to return the object 
 * when this file is required in another module like app.js
 */ 
module.exports = app;